import HikesController from "./HikeController.js";

const hike = new HikesController('hikes');
window.addEventListener('load', () =>{
    hike.showHikeList();
});



